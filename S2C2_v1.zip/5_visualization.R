library(igraph)
library(plyr)


##################################### VISUALIZE IN CYTOSCAPE ###################################

prepare_text_file <- function(graph_list, final_dataframe, pval=0.05){
  final_dataframe_list <- split(final_dataframe, f = final_dataframe$Branch)
  dfs <- c()
  b <- 1
  for(graph in graph_list){
    graph_into_df <- as_long_data_frame(graph)
    final_df_index <- match(graph_into_df$Branch, names(final_dataframe_list))[1]
    if(is.na(final_df_index)==FALSE){
      final_df_subbed <- as.data.frame(final_dataframe_list[final_df_index])
      colnames(final_df_subbed) <- c("From", "To", "Direction", "Type", "Pathway_name", "Database_source", "Conc", "DB_edge_correlation", 
                                     "DB_edge_color", "Branch", "Branch_path", "Signaling_protein", "p_val")
      if(final_df_subbed$p_val[1] < pval){
        dfs[[b]] <- graph_into_df
        graph_into_df$p_val <- rep(final_df_subbed$p_val[1], nrow(graph_into_df))
        b <- b + 1
      } 
      # else {
      #   print("Not passing p-value")
      # }
    }
  }
  dataframe_overall <- ldply(dfs, data.frame)
  if(nrow(dataframe_overall) < 1){
    dataframe_overall <- paste0("No significant activated pathways identified below selected p-value threshold of: ", pval, 
                                ". Consider changing threshold to find more results.")
  } else {
    dataframe_overall <- dataframe_overall[,3:ncol(dataframe_overall)]
    dataframe_overall <- distinct(dataframe_overall, from_name, to_name, .keep_all = TRUE)
    dataframe_overall <- dataframe_overall[c("from_name", "to_name", "from_weight", "from_logFC", "from_color", 
                                             "to_weight", "to_logFC", "to_color", "Edge_weight", "color", "Pathway_name", "Database_source",
                                             "Type", "DB_edge_color", "Signaling_protein", "Branch_path", "Branch")]
    dataframe_overall$to_logFC <- dataframe_overall$to_logFC * 10
    dataframe_overall$to_weight <- dataframe_overall$to_weight * 10
    dataframe_overall$from_logFC <- dataframe_overall$from_logFC * 10
    dataframe_overall$from_weight <- dataframe_overall$from_weight * 10 
    dataframe_overall$Edge_weight <- dataframe_overall$Edge_weight * 10
  }
  return(as.data.frame(dataframe_overall))
}






#write.table(cytoscape_file, paste0(export_directory_path, "/", specified_sender, "_", specified_receiver, "/cytoscape_file.txt"),
            #quote = FALSE, sep = '\t', row.names = FALSE)








############################# VISUALIZE DIFFERENT DATASETS #############################

find_cum_path <- function(net1, net2, net3=NA){
  if(length(net3)<1){
    meta <- rbind(net1, net2)
  } else {
    meta <- rbind(net1, net2, net3)
  }
  meta <- meta[!duplicated(meta[,c(1,2)]),]
  return(meta)
}


cum_nodes <- function(node_table1, node_table2, node_table3=NA, node_table4=NA){
  colnames(node_table1) <- c(colnames(node_table1)[1], paste0(colnames(node_table1), "_AD")[-1])
  colnames(node_table2) <- c(colnames(node_table2)[1],paste0(colnames(node_table2), "_Control")[-1])
  #colnames(node_table3) <- c(colnames(node_table3)[1],paste0(colnames(node_table3), "_6")[-1])
  #colnames(node_table4) <- c(colnames(node_table4)[1],paste0(colnames(node_table4), "_4")[-1])
  df_list <- list(node_table1, node_table2) #add node_table3 for third dataset
  df_merge <- Reduce(function(x,y) merge(x,y,all=TRUE), df_list)
  df_merge[is.na(df_merge)] <- 0
  df_merge$enhancedGraphics <- 'piechart: attributelist="avg_log2FC_AD,avg_log2FC_Control" valuelist="1,1," colorlist="up:red,down:blue,zero:white" range="-0.5,0.5" showlabels=false'
  return(as.data.frame(df_merge))
}


get_proper_nodes <- function(overall_network, total_nodes){
  network_genes <- unique(c(overall_network$from_name, overall_network$to_name))
  total_nodes <- total_nodes[total_nodes$gene %in% network_genes,]
  return(total_nodes)
}

get_df_per_pathway <- function(overall_network){
  overall_network$Pathway_name <- gsub(" ", "_", overall_network$Pathway_name)
  overall_network_list <- split(overall_network, f = overall_network$Pathway_name)
  return(overall_network_list)
}


#total_network <- find_cum_path(ast_mic_AD, ast_mic_Control)
#pathway_network_list <- get_df_per_pathway(total_network)


#nodes <- cum_nodes(ast_mic_ad_nodes, ast_mic_control_nodes)
#pathway_nodes_list <- lapply(pathway_network_list, get_proper_nodes, total_nodes=nodes)