java -jar S2C2-production.jar
