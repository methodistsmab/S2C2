library(Seurat)
library(jsonlite)

print("==== ⭐️ LOADRDS RScript RUN! ⭐️ ====")

save_dir <- getwd()
temp_dir <- file.path(save_dir, "temp")
if (!dir.exists(temp_dir)) {
  dir.create(temp_dir)
} else {
  txt_files <- list.files(temp_dir, pattern = "\\.txt$", full.names = TRUE)
  if (length(txt_files) > 0) {
    file.remove(txt_files)
  }
}

args <- commandArgs(trailingOnly = TRUE)
file_path <- args[1]
seurat_object <- readRDS(file_path)

# Convert factor variables to character
metadata <- as.data.frame(lapply(seurat_object@meta.data, as.character), stringsAsFactors = FALSE)

# print(paste("🚀metadata ====> ", metadata))

column_names <- colnames(metadata)
# print(paste("🔥column_names ====> ", column_names))

metadata_columns_file <- paste0(save_dir, "/metadata_columns.json")
jsonlite::write_json(list(column_names = column_names), path = metadata_columns_file)

for (col_name in column_names) {
  unique_values <- unique(metadata[[col_name]])
  file_name <- paste0(temp_dir, "/", col_name, ".txt")
  write(unique_values, file = file_name)
}

print("==== ⭐️ LOADRDS RScript RUN SUCCESSFULLY! ⭐️ ====")