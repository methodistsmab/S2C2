library(Seurat)
library(SingleCellExperiment)
library(openxlsx)
library(presto)
library(DescTools)

### Run MORABITO dataset
save_dir <- getwd()
source(paste0(save_dir, "/1_start_LR_identified.R"))
source(paste0(save_dir, "/2_identify_select_pathways_backup.R"))
source(paste0(save_dir, "/3_activated_pathways.R"))
source(paste0(save_dir, "/4_permutation_for_significance.R"))
source(paste0(save_dir, "/5_visualization.R"))
seurat_object = readRDS('/Users/vladimirwan/Desktop/Methodist/Project/S2C2-data/ipf.rds')

options(future.globals.maxSize= 891289600)
LR_database = read.delim(paste0(save_dir, '/LR_manual_revised.txt'))
TF_targets = read.delim(paste0(save_dir, '/TF_targets.txt'))
ipa = read.delim(paste0(save_dir, '/IPA_database.txt'))
kegg = read.delim(paste0(save_dir, '/KEGG_all_edge_new.txt'))
pathway_database_list = list(ipa, kegg)



########### S2C2 FUNCTION DEFINITION #####################
sCCCExplorer <- function(seurat_object, 
                         specified_sender, 
                         specified_receiver, 
                         exp_matrix_slot, 
                         global_or_local, 
                         export_directory_path, 
                         condition_colname,
                         celltypecolname,
                         condition1, 
                         LR_database, 
                         TF_targets, 
                         pathway_database_list, 
                         condition2=NA, 
                         percent_exp = 0.005, 
                         logfc_threshold = 0.20, 
                         disease = "AD", 
                         intermediate_downstream_gene_num = 2, 
                         permutation_num = 1000,
                         lambda = 0.5,
                         species = 'human'
                        ){
  start_time <- Sys.time()
  print("Welcome to sCCCExplorer: single-Cell Cross Communication Explorer!")
  # Seurat::Assays(object = seurat_object)
  if(dir.exists(export_directory_path) == FALSE){
    dir.create(export_directory_path)
  }
  export_directory_path <- paste0(export_directory_path, "/S2C2/")
  if(dir.exists(export_directory_path) == FALSE){
    dir.create(export_directory_path)
  }
  
  #  print("============= MATRIX Condition2 ==================")
  #  print(length(condition2))
  # print(paste0("condition2 is => ", condition2))
  
  if(is.na(condition2)==FALSE){
    #   print("condition2 is good?")
    export_directory_path <- paste0(export_directory_path, "sender_", specified_sender, "_receiver_", specified_receiver)
  } else {
    export_directory_path <- paste0(export_directory_path, "sender_", specified_sender, "_receiver_", specified_receiver, "_", condition2) 
  }
  
  if (!dir.exists(export_directory_path)) {
    dir.create(export_directory_path)
  }
  
  ### Prepare the Seurat Object
  ### Remove any cell type with less than 3 cells
  celltypes <- levels(Idents(seurat_object))
  if(is.na(condition2)==FALSE){ # We have condition1 and condition 2
    original_celltypes <- unique(seurat_object[[celltypecolname]][[1]])
    seurat_object$temp <- paste0(as.list(seurat_object[[celltypecolname]][[1]]), '_', as.list(seurat_object[[condition_colname]][[1]]))
    tb <- table(seurat_object$temp)
    celltypes <- names(tb)
    n_celltypes <- c()
    for (i in 1:length(celltypes)){
      if (tb[[i]][1] > 3){
        n_celltypes <- c(n_celltypes, celltypes[i])
      }
    }
    # Make sure to check both condition1 and condition2 satisfies the cell number
    conditions <- c(condition1, condition2)
    final_celltypes <- c()
    for (j in 1:length(original_celltypes)){
      if (all(paste0(original_celltypes[j],'_',conditions) %in% n_celltypes)){
        final_celltypes <- c(final_celltypes, original_celltypes[j])
      }
    }
    Idents(seurat_object) <- celltypecolname
    seurat_object<- subset(x = seurat_object, idents = final_celltypes)
  } else { #condition 2 is NA
    original_celltypes <- unique(seurat_object[[celltypecolname]][[1]])
    seurat_object$temp <- paste0(as.list(seurat_object[[celltypecolname]][[1]]), '_', as.list(seurat_object[[condition_colname]][[1]]))
    tb <- table(seurat_object$temp)
    celltypes <- names(tb)
    n_celltypes <- c()
    for (i in 1:length(celltypes)){
      if (tb[[i]][1] > 3){
        n_celltypes <- c(n_celltypes, celltypes[i])
      }
    }
    final_celltypes <- c()
    # Only make sure to check condition1 satisfies the cell number
    for (j in 1:length(original_celltypes)){
      if (all(paste0(original_celltypes[j],'_',condition1) %in% n_celltypes)){
        final_celltypes <- c(final_celltypes, original_celltypes[j])
      }
    }
    Idents(seurat_object) <- celltypecolname
    seurat_object<- subset(x = seurat_object, idents = final_celltypes)
  }
  
  #1: prepare external pathway databases
  # source("./prepare_databases.R")
  collective_database <- prepare_database(pathway_database_list, disease = "AD")
  print("================== Database Preview (following collective_database is ) ==================")
  print(head(collective_database))
  print("================== 1 ✅  ========================")
  
  #2: find differentially expressed genes for sender and overall expression for receiver
  print("Determining Overall Expression of Receiver and Differentially Expressed Genes for Sender")
  print(paste0("Specified Sender: ", specified_sender))
  print(paste0("Specified Receiver: ", specified_receiver))
  results <- find_sender_receiver_genes(seurat_object = seurat_object, specified_sender = specified_sender, specified_receiver = specified_receiver, condition_colname = condition_colname, condition1 = condition1, condition2 = condition2,
                                        percent_exp = percent_exp, logfc_threshold = logfc_threshold, assay = assay)
  pre_dataframes <- results[[1]]
  markers_df <- results[[2]]
  # gene_intersect <-rownames(markers_df[[1]])
  # for (idx in 2:length(markers_df)){
  #   gene_intersect <- intersect(gene_intersect, rownames(markers_df[[idx]]))
  # }
  # for (idx in 1:length(markers_df)){
  #   markers_df[[idx]] <- markers_df[[idx]][gene_intersect,]
  # }
  print("================== 2 ✅  ==========================")
  
  
  if (species != 'human'){
    ### Modify the list to human gene names.
    df1_s <- paste0("Sender_Markers_", specified_sender)
    df2_r <- paste0("Receiver_Overall_", specified_receiver)
    
    # pre_dataframes[df1_s]
    lookup <- homologene::mouse2human(rownames(pre_dataframes[df1_s][[1]]), db = homologene::homologeneData2)
    new_rownames <- lookup$humanGene[match(rownames(pre_dataframes[df1_s][[1]]), lookup$mouseGene)]
    for (i in 1:length(new_rownames)){
      if (isTRUE(is.na(new_rownames[i]))){
        new_rownames[i] <- toupper(rownames(pre_dataframes[df1_s][[1]])[i])
      }
    }
    
    pre_dataframes[df1_s][[1]]$gene <- new_rownames
    pre_dataframes[df1_s][[1]] <- pre_dataframes[df1_s][[1]] %>% distinct(gene, .keep_all = TRUE)
    rownames(pre_dataframes[df1_s][[1]]) <- pre_dataframes[df1_s][[1]]$gene 
    
    # pre_dataframes[df2_r]
    lookup <- homologene::mouse2human(rownames(pre_dataframes[df2_r][[1]]), db = homologene::homologeneData2)
    new_rownames <- lookup$humanGene[match(rownames(pre_dataframes[df2_r][[1]]), lookup$mouseGene)]
    for (i in 1:length(new_rownames)){
      if (isTRUE(is.na(new_rownames[i]))){
        new_rownames[i] <- toupper(rownames(pre_dataframes[df2_r][[1]])[i])
      }
    }
    pre_dataframes[df2_r][[1]]$gene <- new_rownames
    pre_dataframes[df2_r][[1]] <- pre_dataframes[df2_r][[1]] %>% distinct(gene, .keep_all = TRUE)
    rownames(pre_dataframes[df2_r][[1]]) <- pre_dataframes[df2_r][[1]]$gene 
    
    # Markers_df
    for (mdf in 1:length(markers_df)){
      lookup <- homologene::mouse2human(rownames(markers_df[[mdf]]), db = homologene::homologeneData2)
      new_rownames <- lookup$humanGene[match(rownames(markers_df[[mdf]]), lookup$mouseGene)]
      for (i in 1:length(new_rownames)){
        if (isTRUE(is.na(new_rownames[i]))){
          new_rownames[i] <- toupper(rownames(markers_df[[mdf]])[i])
        }
      }
      markers_df[[mdf]]$gene <- new_rownames
      markers_df[[mdf]]<- markers_df[[mdf]][!duplicated(markers_df[[mdf]]$gene),]
      rownames(markers_df[[mdf]]) <- markers_df[[mdf]]$gene
    }
  }
  
  user_dataframes <- prepare_sender_receiver(pre_dataframes[[1]], pre_dataframes[[2]], collective_database, logfc_threshold = logfc_threshold, condition1 = condition1, condition2 = condition2)
  
  print("Exporting Sender Differentially Expressed Markers and Receiver Overall Expression Values")
  write.table(user_dataframes$sender_dataframe, paste0(export_directory_path, "/sender_markers_", specified_sender, ".txt"), quote = FALSE, sep = '\t', row.names = FALSE)
  write.table(user_dataframes$receiver_dataframe, paste0(export_directory_path, "/receiver_overall_", specified_receiver, ".txt"), quote = FALSE, sep = '\t', row.names = FALSE)
  print("================== 3 ✅  ============================")
  
  #4: find expressed ligand receptors
  print("Finding Expressed Ligand Receptor Interactions (LR pairs)")
  ligand_receptor_dataframe <- find_ligand_receptor_pairs(seurat_object = seurat_object, markers_df = markers_df, specified_sender = specified_sender, specified_receiver = specified_receiver, sender_df = user_dataframes$sender_dataframe, receiver_df = user_dataframes$receiver_dataframe, 
                                                          LR_database = LR_database, condition_colname = condition_colname, condition1 = condition1, condition2 = condition2)
  
  if(length(ligand_receptor_dataframe) == 1){
    result <- "No Identified Ligand Receptor Pairs found in Crosstalk"
    print(result)
    write(result, paste0(export_directory_path, "/no_ligand_receptors.txt"))
  } else {
    print("Exporting Expressed Ligand Receptor Dataframe to export directory path")
    write.table(ligand_receptor_dataframe, paste0(export_directory_path, "/LR_pairs.txt"), quote = FALSE, row.names = FALSE, sep = '\t')
    print("================== 4 ✅  ========================")
    
    #5: find activated pathways
    print("Finding Possible Pathways from Identified LR pairs")
    prelim_LRs <- find_preliminary_pathways(ligand_receptor_dataframe, collective_database)
    print("Finding Possible Activated Pathways")
    activated_pathways_overview <- find_activated_branches(prelim_LRs, user_dataframes$receiver_dataframe, intermediate_downstream_gene_num = intermediate_downstream_gene_num, TF_targets = TF_targets)
    if(length(activated_pathways_overview) == 1){
      result <- "sCCCExplorer cannot continue crosstalk pathway analysis. User-specific downstream targets were not found in the expression data provided."
      print(result)
      write(result, paste0(export_directory_path, "/no_pathways.txt"))
    } else {
      node_table <- create_node_exp_table(activated_pathways_overview, user_dataframes$sender_dataframe, user_dataframes$receiver_all_dataframe)
      print("Exporting Node/Vertex table of avg_log2FC values to export directory path")
      write.table(node_table, paste0(export_directory_path, "/node_table_logFC.txt"), quote = FALSE, sep = '\t', row.names = FALSE)
      print("================== 5 ✅  ===========================")
      
      #6: assign weights to each graph
      print("Assigning User Specific Values to Each Activated Pathway Identified: ")
      if (species != 'human'){
        # weighted_graphs <- construct_weighted_graph_ST(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
        #                                                receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        output <- construct_weighted_graph_ST(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
                                              receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        weighted_graphs <- output[[1]]
        new_pathway_df_list <- output[[2]]
        
      } else {
        # weighted_graphs <- construct_weighted_graph(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
        #                                             receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        output <- construct_weighted_graph(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
                                           receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        weighted_graphs <- output[[1]]
        new_pathway_df_list <- output[[2]]
        
      }
      print("================== 6 ✅  =========================")
      
      #7: determine significance of each branch based on permutation test
      print("Calculating Pathway Significance by Permutation Test")
      # weights_dataframe <- c()
      # for (i in 1:length(markers_df)){weights_dataframe<-rbind(weights_dataframe, markers_df[[i]])}
      # weights_dataframe <- FindMarkers(seurat_object, ident.1 = specified_receiver, features = rownames(seurat_object), min.pct = 0, verbose = FALSE, logfc.threshold = 0, test.use = "wilcox")
      final_dataframe <- find_sig_of_pathway_branches_v2(graph_list = weighted_graphs, export_directory_path=export_directory_path, collective_database = collective_database, overall_dataframe = new_pathway_df_list, receiver_df = user_dataframes$receiver_all_dataframe, permutation_num = permutation_num, lambda=lambda)
      print("Exporting Ranked Pathway's Significance to export directory path")
      write.table(final_dataframe, paste0(export_directory_path, "/significant_branches.txt"), sep = '\t', quote = FALSE, row.names = FALSE)
      print("================== 7 ✅  ==========================")
      
      #8: create text file for visualization 
      cytoscape_all <- prepare_text_file(weighted_graphs, final_dataframe, pval = 1)
      write.table(cytoscape_all, paste0(export_directory_path, "/cytoscape_all_file.txt"),
                  quote = FALSE, sep = '\t', row.names = FALSE)
      cytoscape_file <- prepare_text_file(weighted_graphs, final_dataframe)
      print("Exporting Pathway Table as text file to export directory path")
      write.table(cytoscape_file, paste0(export_directory_path, "/cytoscape_significant_file.txt"),
                  quote = FALSE, sep = '\t', row.names = FALSE)
      print("S2C2 Complete!")
      end_time <- Sys.time()
      print(end_time - start_time)
      print("================== 8 ✅  ========================")
    }
  }
}



# celltypes = c("T_cell","NK_cell")
celltypes = c("T_cell","NK_cell","Monocyte","Endothelial","B_cell")
sender_receiver_list <- CombSet(celltypes, 2, repl=TRUE, ord=TRUE)
autocrine <- c(1, 7, 13, 19, 25)
# for (z in 1:nrow(sender_receiver_list)){

start_time <- Sys.time()

for (z in autocrine){
  sCCCExplorer(seurat_object = seurat_object,
               specified_sender = sender_receiver_list[z,1],
               specified_receiver = sender_receiver_list[z,2],
               exp_matrix_slot = "scale.data",
               global_or_local = "global",
               export_directory_path = paste0(save_dir, '/jianting_paper/'),
               celltypecolname = "cell_type_Jan2524",
               condition_colname = "Diagnosis",
               condition1="Control", # should be AD
               LR_database = LR_database,
               TF_targets = TF_targets,
               pathway_database_list=pathway_database_list,
               condition2='NA', # should be Control
               percent_exp = 0.005, # or 0.1
               logfc_threshold = 0.20,
               disease = "AD", 
               intermediate_downstream_gene_num = 2, 
               permutation_num = 1000, # or 1000
               lambda = 0.0,
               species = 'mouse'
  )
}

end_time <- Sys.time()

total_time <- end_time - start_time

print(total_time)

#### Generate a figure for a grant application
#### Interaction map figure between different cell types.
#### 0, 1, 2, 3, 7
save_dir <- getwd()
filenames <- list.files(save_dir)
data_dir = paste0(save_dir,"/",filenames)
# Treg_idx <- grep("Treg",filenames)
# OS_idx <- grep("Osteosarcoma",filenames)
# MDSC_idx <- grep("Neutrophil MDSC",filenames)
# Mac_idx <- grep("Activated Macrophage",filenames)
# Treg_OS <- intersect(Treg_idx, OS_idx)
# Treg_MDSC <- intersect(Treg_idx, MDSC_idx)
# Treg_Mac <- intersect(Treg_idx, Mac_idx)
# OS_MDSC <- intersect(OS_idx, MDSC_idx)
# OS_Mac <- intersect(OS_idx, Mac_idx)
# MDSC_Mac <- intersect(MDSC_idx, Mac_idx)
# Treg_Treg <- grep("sender_Treg_receiver_Treg", filenames)
# OS_OS <- grep("sender_Treg_receiver_Treg", filenames)
# MDSC_MDSC <- grep("sender_Treg_receiver_Treg", filenames)
# Mac_Mac <- grep("sender_Treg_receiver_Treg", filenames)
# overall_idx <- sort(c(Treg_OS,Treg_MDSC,Treg_Mac,OS_MDSC,OS_Mac,MDSC_Mac))

exh_t <- grep("Exhausted T", filenames)
lamp3 <- grep("LAMP3+", filenames)
exclude_idx <- sort(unique(c(exh_t, lamp3)))
all_idx <- grep("sender", filenames)
tested_cell_idx <- c(all_idx, exclude_idx)
tested_cell_idx <- tested_cell_idx[!(duplicated(tested_cell_idx)|duplicated(tested_cell_idx, fromLast=TRUE))]

df <- data.frame(Sender=character(),
                 Receiver=character(),
                 LR_pairs=integer())

for (i in 1:length(data_dir)){
  LR_pairs <- read.csv(paste0(data_dir[i],'/LR_pairs.txt'),sep='\t')
  sender <- strsplit(strsplit(filenames[i],'_receiver')[[1]][1], 'sender_')[[1]][2]
  receiver <- strsplit(strsplit(filenames[i],'_receiver_')[[1]][2], '_NA')[[1]][1]
  
  new_row <- c(sender,receiver,nrow(LR_pairs))
  df <- rbind(df, new_row)
}
colnames(df) <- c("Sender", "Receiver", "LR_pairs")

celltypes <- unique(df$Sender)
df2 <- data.frame()
for (i in 1:length(celltypes)){
  to <- celltypes[i]
  idx = which(df$Receiver == to)
  new_row <- df$LR_pairs[idx]
  df2 <- rbind(df2, as.numeric(new_row))
}
rownames(df2) = celltypes
colnames(df2) = celltypes
# library(chorddiag)
# groupColors <- c("#000000", "#FFDD89", "#957244", "#F26223", "#2171b5","#bababa")
# chorddiag(as.matrix(df2), groupColors = groupColors, groupnamePadding = 20, tickInterval = 50)

library(circlize)
# directional with value 1 means the direction is from rows to columns (or from the first column to the second column for the adjacency list

row.col <- c("#95724450", "#bababa50", "#0000FF50","#FFDD8950", "#00000050")
grid.col = c('0' = "#957244", '1' = "#bababa", '2' = "blue",
             '3' = "#FFDD89", '7' = "#000000")
chordDiagram(as.matrix(df2), directional = 1, transparency = 0.5, grid.col = 1:5)
chordDiagram(as.matrix(df2), directional = 1, transparency = 0.5, grid.col = 1:5, row.col = row.col[1:3])
chordDiagram(df, directional = 1, transparency = 0.5, grid.col = 1:5, link.arr.type = "big.arrow")
chordDiagram(as.matrix(df2), directional = 1, transparency = 0.5, grid.col = 1:5,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow",scale = TRUE)
chordDiagram(as.matrix(df2), transparency = 0.5, grid.col = grid.col,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow")
row.col <- c("#95724410", "#bababa10", "#0000FF05","#FFDD89", "#00000010")
chordDiagram(as.matrix(df2), transparency = 0.5, grid.col = grid.col,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow", row.col = row.col)
circos.clear()




#### Code to generate a chord diagram
#### Interaction map figure between different cell types.
save_dir <- '/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_S2C2_Jun_8 1'
filenames <- list.files(save_dir)
data_dir = paste0(save_dir,"/",filenames)

df <- data.frame(Sender=character(),
                 Receiver=character(),
                 LR_pairs=integer())
for (i in 1:length(data_dir)){
  sender_receiver <- list.files(data_dir[i], pattern = 'sender_')
  sender_name <- strsplit(strsplit(sender_receiver, 'sender_')[[1]][2],'_receiver_')[[1]][1]
  receiver_name <- strsplit(strsplit(sender_receiver, '_receiver_')[[1]][2],'_NA')[[1]][1]
  results_dir = paste0(data_dir[i],'/',sender_receiver)
  
  LR_pairs <- read.csv(paste0(results_dir,'/LR_pairs.txt'),sep='\t')
  new_row <- c(sender_name,receiver_name,nrow(LR_pairs))
  df <- rbind(df, new_row)
}
colnames(df) <- c("Sender", "Receiver", "LR_pairs")

## Split df into different experiments

### cDC, pDC to Th17, Treg, Tc17, CD8Treg
df1 <- df[1:8,]
### cDC, pDC to EM, RM, CM
df2 <- df[9:14,]
### EM, RM, CM to EM, RM, CM
df3 <- df[15:23,]
# 

library(circlize)
# directional with value 1 means the direction is from rows to columns (or from the first column to the second column for the adjacency list

row.col <- c("#95724450", "#bababa50", "#0000FF50","#FFDD8950", "#00000050")

grid.col = c('cDC' = "#FFD700", 'pDC' = "#1E90FF", 'CD8Treg' = "#32CD32",
             'Tc17' = "#FF69B4", 'Th17' = "#8A2BE2", 'Treg' = '#FF4500',
             'EM'= '#ADD8E6', 'RM'='#FF6347', 'CM'='#90EE90')

colnames(df1) = c('from', 'to', 'value')
colnames(df2) = c('from', 'to', 'value')
colnames(df3) = c('from', 'to', 'value')

# Reshape the DataFrame to wide format
mat <- dcast(df1, from ~ to, value.var = "value")
# Ensure that the mat columns are numeric
mat[,-1] <- lapply(mat[,-1], as.numeric)
# Set row names and convert to matrix
row.names(mat) <- mat$from
mat$from <- NULL  # Remove the 'from' column as it is now row names
mat1 <- as.matrix(mat)

# Reshape the DataFrame to wide format
mat <- dcast(df2, from ~ to, value.var = "value")
# Ensure that the mat columns are numeric
mat[,-1] <- lapply(mat[,-1], as.numeric)
# Set row names and convert to matrix
row.names(mat) <- mat$from
mat$from <- NULL  # Remove the 'from' column as it is now row names
mat2 <- as.matrix(mat)


# Reshape the DataFrame to wide format
mat <- dcast(df3, from ~ to, value.var = "value")
# Ensure that the mat columns are numeric
mat[,-1] <- lapply(mat[,-1], as.numeric)
# Set row names and convert to matrix
row.names(mat) <- mat$from
mat$from <- NULL  # Remove the 'from' column as it is now row names
mat3 <- as.matrix(mat)


# 
### cDC, pDC to Th17, Treg, Tc17, CD8Treg
chordDiagram((mat1), transparency = 0.5, grid.col = grid.col,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow",scale = FALSE)
circos.clear()
### cDC, pDC to EM, RM, CM
chordDiagram((mat2), transparency = 0.5, grid.col = grid.col,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow",scale = FALSE)
circos.clear()
### EM, RM, CM to EM, RM, CM
chordDiagram((mat3), transparency = 0.5, grid.col = grid.col,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow",scale = FALSE)
circos.clear()



########## Had issues with after treatment group with cells less than 3 
### Run Kun's dataset
save_dir <- getwd()
source(paste0(save_dir, "/1_start_LR_identified.R"))
source(paste0(save_dir, "/2_identify_select_pathways_backup.R"))
source(paste0(save_dir, "/3_activated_pathways.R"))
source(paste0(save_dir, "/4_permutation_for_significance.R"))
source(paste0(save_dir, "/5_visualization.R"))
seurat_object = readRDS('/Users/vladimirwan/Desktop/Methodist/Project/S2C2-data/ipf.rds')

#PARAMETERS 
options(future.globals.maxSize= 891289600)
LR_database = read.delim(paste0(save_dir, '/LR_manual_revised.txt'))
TF_targets = read.delim(paste0(save_dir, '/TF_targets.txt'))
ipa = read.delim(paste0(save_dir, '/IPA_database.txt'))
kegg = read.delim(paste0(save_dir, '/KEGG_all_edge_new.txt'))
pathway_database_list = list(ipa, kegg)



celltypes = c("T cell","NK cell","Monocyte","Endothelial","B cell")
sender_receiver_list <- CombSet(celltypes, 2, repl=TRUE, ord=TRUE)
autocrine <- c(1, 7, 13, 19, 25)


start_time <- Sys.time()

for (z in 1:nrow(sender_receiver_list)){
  sCCCExplorer(seurat_object = seurat_object,
               specified_sender = sender_receiver_list[z,1],
               specified_receiver = sender_receiver_list[z,2],
               exp_matrix_slot = "scale.data",
               global_or_local = "global",
               export_directory_path = paste0(save_dir, '/jianting_paper/'),
               condition_colname = "Diagnosis",
               celltypecolname = 'cell_type_Jan2524',
               condition1="Control", # should be AD
               LR_database = LR_database,
               TF_targets = TF_targets,
               pathway_database_list=pathway_database_list,
               condition2=NA, # should be Control
               percent_exp = 0.005, # or 0.1
               logfc_threshold = 0.20,
               disease = "AD", 
               intermediate_downstream_gene_num = 2, 
               permutation_num = 1000, # or 1000
               lambda = 0.0,
               species = 'mouse'
  )
}

end_time <- Sys.time()
total_time <- end_time - start_time
print(total_time)

### Redo the thrid figure
save_dir <- '/Users/vladimirwan/Desktop/Methodist/Project/S2C2-source-code/jianting_paper/S2C2'
filenames <- list.files(save_dir)
data_dir = paste0(save_dir,"/",filenames)

df <- data.frame(Sender=character(),
                 Receiver=character(),
                 LR_pairs=integer())

for (i in 1:length(data_dir)){
  sender_name <- strsplit(strsplit(data_dir[i], 'sender_')[[1]][2],'_receiver_')[[1]][1]
  receiver_name <- strsplit(strsplit(data_dir[i], '_receiver_')[[1]][2],'_NA')[[1]][1]
  
  LR_pairs <- read.csv(paste0(data_dir[i],'/LR_pairs.txt'),sep='\t')
  new_row <- c(sender_name,receiver_name,nrow(LR_pairs))
  df <- rbind(df, new_row)
}
colnames(df) = c('from', 'to', 'value')
library(circlize)
# directional with value 1 means the direction is from rows to columns (or from the first column to the second column for the adjacency list

# Reshape the DataFrame to wide format
mat <- dcast(df, from ~ to, value.var = "value")
# Ensure that the mat columns are numeric
mat[,-1] <- lapply(mat[,-1], as.numeric)
# Set row names and convert to matrix
row.names(mat) <- mat$from
mat$from <- NULL  # Remove the 'from' column as it is now row names
mat <- as.matrix(mat)

chordDiagram((mat), transparency = 0.5, grid.col = grid.col,
             directional = 1, direction.type = c("diffHeight", "arrows"),
             link.arr.type = "big.arrow",scale = FALSE)
circos.clear()


### Alluvial plot for Kun
library(ggplot2)
library(ggalluvial)
library(ggrepel)
library(gridExtra)
library(patchwork)

# '/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_after_treatment/S2C2'
# /Users/vladimirwan/Desktop/Methodist/Project/S2C2-source-code/jianting_paper/S2C2
save_dir <- '/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_S2C2_Jun_8 1'
filenames <- list.files(save_dir)
data_dir = paste0(save_dir,"/",filenames)



ligands_to_remove <- c("CCL11", "CCL13","COL1A2","COL4A1","CSF1","EDN1","FN1","ICAM1","IGF1","IL1A","IL1B","PDGFA","PGF","THBS1","THBS4","TNC","VEGFA","VEGFC",
                       "CCL24", "COL1A1","COL5A2","HBEGF","THBS3",
                       "COL3A1","COL6A1", "FGF23", 
                       "F7",
                       "APLN","ICAM2","KITLG","LTB")

receptors_to_remvoe <- c("CCR1","CCR2","CSF1R","EDNRA","FLT1","FLT4","IGF1R","ITGB3","ITGB8","LTBR","PDGFRB",
                         "EGFR",
                         "FGFR1", "PDGFRA", "TNFRSF11A",
                         "F3",
                         "LRP5",
                         "APLNR","KIT")

# i = 9 cDC - EM
# i = 10 cDC - RM
# i = 11 cDC - CM
# i = 15 EM - EM (before tx)
# i = 18 RM - EM (before tx)
# i = 21 CM - EM (before tx)
for (i in 1:length(data_dir)){
  sender_receiver <- list.files(data_dir[i], pattern = 'sender_')
  sender_name <- strsplit(strsplit(sender_receiver, 'sender_')[[1]][2],'_receiver_')[[1]][1]
  receiver_name <- strsplit(strsplit(sender_receiver, '_receiver_')[[1]][2],'_NA')[[1]][1]
  results_dir = paste0(data_dir[i],'/',sender_receiver)
  
  LR_pairs <- read.csv(paste0(results_dir,'/LR_pairs.txt'),sep='\t')
  sig_branches <- read.csv(paste0(results_dir,'/significant_branches.txt'),sep='\t')
  
  sig_branches <- sig_branches[sig_branches$Signaling_protein == "Ligand",]
  LR_names <- unique(sig_branches$Conc)
  LR_pairs$Conc <- paste0(LR_pairs$Ligand, LR_pairs$Receptor)
  LR_pairs_subset <- LR_pairs[is.element(LR_pairs$Conc, LR_names),]
  
  for (j in 1:nrow(sig_branches)){
    sig_branches$enrichment_score[j] <- LR_pairs_subset[LR_pairs_subset$Conc == sig_branches$Conc[j],]$enrichment_score
    sig_branches$Ligand_foldChange[j] <- LR_pairs_subset[LR_pairs_subset$Conc == sig_branches$Conc[j],]$Ligand_foldChange
    sig_branches$Receptor_foldChange[j] <- LR_pairs_subset[LR_pairs_subset$Conc == sig_branches$Conc[j],]$Receptor_foldChange
  }
  # Remove 'signaling_pathway' from the Pathway_name column
  sig_branches$Pathway_name <- gsub('_signaling_pathway', '', sig_branches$Pathway_name)
  # Trim any extra whitespace that might remain after removal
  sig_branches$Pathway_name <- trimws(sig_branches$Pathway_name)

  sig_branches$enrichment_category <- cut(sig_branches$enrichment_score, 
                                          breaks = c(-Inf, 0.5, 1, 1.5, 2, 2.5, Inf),
                                          labels = c("0 - 0.5", "0.5 - 1", "1 - 1.5", "1.5 - 2", "2 - 2.5", "> 2.5"))
  # Reverse the order of the levels
  sig_branches$enrichment_category <- factor(sig_branches$enrichment_category, 
                                             levels = c("> 2.5", "2 - 2.5", "1.5 - 2", "1 - 1.5", "0.5 - 1", "0 - 0.5"))
  
  # Rename Natural_killer_cell_mediated_cytotoxicity to Cytotoxicity
  idx = which(sig_branches$Pathway_name == "Natural_killer_cell_mediated_cytotoxicity")
  if(length(idx) != 0){sig_branches$Pathway_name[idx] <- "Cytotoxicity"}
  
  # 
  # # Remove F7 and F3 from analysis
  # idx2 = which(sig_branches$From == "F7")
  # if(length(idx2) != 0){sig_branches = sig_branches[-idx2,]}

  for (k in 1:length(receptors_to_remvoe)){
    idx3 = which(sig_branches$To == receptors_to_remvoe[k])
    print(length(idx3))
    if(length(idx3) != 0){sig_branches = sig_branches[-idx3,]}
  }
  for (m in 1:length(ligands_to_remove)){
    idx4 = which(sig_branches$From == ligands_to_remove[m])
    print(length(idx4))
    if(length(idx4) != 0){sig_branches = sig_branches[-idx4,]}
  }
  
  # # cDC - EM
  # # receptors to remove: CSF1R, F3, FLT1, FZD4, FZD7, FZD1, LTBR, OSMR, PDGFRB, TNFRSF11A
  # receptors_remove = c("CSF1R", "F3", "FLT1", "FZD4", "FZD7", "FZD8", "LTBR", "OSMR", "PDGFRB", "TNFRSF11A")
  # for (k in 1:length(receptors_remove)){
  #   idx3 = which(sig_branches$To == receptors_remove[k])
  #   print(length(idx3))
  #   if(length(idx3) != 0){sig_branches = sig_branches[-idx3,]}
  # }
  # ligand_separate = c("IFNG")
  # n_sig_branches =c()
  # for (m in 1:length(ligand_separate)){
  #   idx4 = which(sig_branches$From == ligand_separate[m])
  #   print(length(idx4))
  #   if(length(idx4) != 0){
  #     n_sig_branches = rbind(n_sig_branches,sig_branches[idx4,])
  #     sig_branches = sig_branches[-idx4,]
  #     }
  # }
  
  # # cDC - CM
  # receptors_remove = c("CSF1R", "FGFR1", "FLT4", "KDR", "LRP5", "LTBR", "PDGFRB")
  # for (k in 1:length(receptors_remove)){
  #   idx3 = which(sig_branches$To == receptors_remove[k])
  #   print(length(idx3))
  #   if(length(idx3) != 0){sig_branches = sig_branches[-idx3,]}
  # }
  # ligand_separate = c("FN1","IFNG")
  # n_sig_branches =c()
  # for (m in 1:length(ligand_separate)){
  #   idx4 = which(sig_branches$From == ligand_separate[m])
  #   print(length(idx4))
  #   if(length(idx4) != 0){
  #     n_sig_branches = rbind(n_sig_branches,sig_branches[idx4,])
  #     sig_branches = sig_branches[-idx4,]
  #     }
  # }
  
  # # cDC - RM
  # receptors_remove = c("CSF1R", "F3", "FLT1", "FLT4","FZD4", "ITGB3", "ITGB2", "LTBR", "OSMR", "PDGFRA")
  # for (k in 1:length(receptors_remove)){
  #   idx3 = which(sig_branches$To == receptors_remove[k])
  #   print(length(idx3))
  #   if(length(idx3) != 0){sig_branches = sig_branches[-idx3,]}
  # }
  # 
  # ligand_separate = c("FGF2", "FGF7", "FN1")
  # n_sig_branches =c()
  # for (m in 1:length(ligand_separate)){
  #   idx4 = which(sig_branches$From == ligand_separate[m])
  #   print(length(idx4))
  #   if(length(idx4) != 0){
  #     n_sig_branches = rbind(n_sig_branches,sig_branches[idx4,])
  #     sig_branches = sig_branches[-idx4,]
  #   }
  # }
  
  
  # p1 <- ggplot(data = sig_branches,
  #              aes(axis1 = From, axis2 = To, axis3 = Pathway_name)) +
  #   scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), position = 'bottom') +
  #   # scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), expand = c(.2, -.05)) +
  #   geom_alluvium(aes(fill = enrichment_category)) +
  #   geom_stratum() +
  #   geom_text(stat = "stratum", aes(label = after_stat(stratum)), fontface = "bold", size = 3) +
  #   theme_void() +
  #   ggtitle(paste0(sender_name, ' - ', receiver_name, " Crosstalk")) +
  #   labs(fill='Enrichment Score') +
  #   theme(plot.title = element_text(size=20),
  #         legend.title = element_text(size=20),
  #         legend.text = element_text(size=15),
  #         axis.text.y = element_blank(),
  #         axis.text=element_text(size=25,face="bold"),
  #         plot.margin = margin(t = 0, r = 5, b = 0, l = 5),
  #         axis.text.x = element_text(margin = margin(t = -15)))+
  #   scale_fill_manual(values = c("> 2.5" = '#9932cc',
  #                                "2 - 2.5" = '#ba55d3', 
  #                                "1.5 - 2" = '#7b68ee', 
  #                                "1 - 1.5" = '#6495ed', 
  #                                "0.5 - 1" = '#87ceeb', 
  #                                "0 - 0.5" = '#add8e6'))
  # 
  # p2 <- ggplot(data = n_sig_branches,
  #        aes(axis1 = From, axis2 = To, axis3 = Pathway_name)) +
  #   # scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), expand = c(.2, .05)) +
  #   scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), position = 'bottom') +
  #   geom_alluvium(aes(fill = enrichment_category)) +
  #   geom_stratum() +
  #   geom_text(stat = "stratum", aes(label = after_stat(stratum)), fontface = "bold", size = 3) +
  #   theme_void() +
  #   labs(fill='Enrichment Score') +
  #   theme(plot.title = element_text(size=20),
  #         legend.title = element_text(size=20),
  #         legend.text = element_text(size=15),
  #         axis.text.y = element_blank(),
  #         axis.text=element_text(size=25,face="bold"))+
  #   scale_fill_manual(values = c("> 2.5" = '#9932cc',
  #                                "2 - 2.5" = '#ba55d3', 
  #                                "1.5 - 2" = '#7b68ee', 
  #                                "1 - 1.5" = '#6495ed', 
  #                                "0.5 - 1" = '#87ceeb', 
  #                                "0 - 0.5" = '#add8e6'))
  # 
  # combined_plot <- (p1 / p2)  +
  #   plot_layout(heights = c(3, 1))
  
  ggplot(data = sig_branches,
         aes(axis1 = From, axis2 = To, axis3 = Pathway_name)) +
    scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), position = 'bottom') +
    # scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), expand = c(.2, -.05)) +
    geom_alluvium(aes(fill = enrichment_category)) +
    geom_stratum() +
    geom_text(stat = "stratum", aes(label = after_stat(stratum)), fontface = "bold", size = 3) +
    theme_void() +
    ggtitle(paste0(sender_name, ' - ', receiver_name, " Crosstalk")) +
    labs(fill='Enrichment Score') +
    theme(plot.title = element_text(size=20),
          legend.title = element_text(size=20),
          legend.text = element_text(size=15),
          axis.text.y = element_blank(),
          axis.text=element_text(size=25,face="bold"),
          plot.margin = margin(t = 0, r = 5, b = 0, l = 5),
          axis.text.x = element_text(margin = margin(t = -15)))+
    scale_fill_manual(values = c("> 2.5" = '#9932cc',
                                 "2 - 2.5" = '#ba55d3', 
                                 "1.5 - 2" = '#7b68ee', 
                                 "1 - 1.5" = '#6495ed', 
                                 "0.5 - 1" = '#87ceeb', 
                                 "0 - 0.5" = '#add8e6'))
  ggsave(paste0('/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_Grant/Alluvial_plotv6/before_tx_',sender_name,'_',receiver_name,'.pdf'), width = 15, height = 10)
  # ggsave(paste0('/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_Grant/Alluvial_plotv6/',sender_name,'_',receiver_name,'.pdf'), width = 15, height = 15)
}

### Code to generate an alluvial plot.

# /Users/vladimirwan/Desktop/Methodist/Project/S2C2-source-code/jianting_paper/S2C2
save_dir <- '/Users/vladimirwan/Desktop/Methodist/Project/S2C2-source-code/jianting_paper/S2C2'
filenames <- list.files(save_dir)
data_dir = paste0(save_dir,"/",filenames)

for (i in 1:length(data_dir)){
  sender_name <- strsplit(strsplit(data_dir[i], 'sender_')[[1]][2],'_receiver_')[[1]][1]
  receiver_name <- strsplit(strsplit(data_dir[i], '_receiver_')[[1]][2],'_NA')[[1]][1]
  
  LR_pairs <- read.csv(paste0(data_dir[i],'/LR_pairs.txt'),sep='\t')
  sig_branches <- read.csv(paste0(data_dir[i],'/significant_branches.txt'),sep='\t')
  

  # print(data_dir[i])
  sig_branches <- sig_branches[sig_branches$Signaling_protein == "Ligand",]
  
  
  if(nrow(sig_branches) == 0) {
    print(paste("Skipping", sender_name, "-", receiver_name, "due to empty sig_branches"))
    next
  }
  
  print(sig_branches)
  print("==============🐦=====================")
  
  print("==============🔥=====================")
  print(class(LR_pairs$enrichment_score))
  print(head(LR_pairs$enrichment_score))
  print("==============✅=====================")
  
  LR_names <- unique(sig_branches$Conc)
  LR_pairs$Conc <- paste0(LR_pairs$Ligand, LR_pairs$Receptor)
  LR_pairs_subset <- LR_pairs[is.element(LR_pairs$Conc, LR_names),]
  
  for (j in 1:nrow(sig_branches)){
    sig_branches$enrichment_score[j] <- LR_pairs_subset[LR_pairs_subset$Conc == sig_branches$Conc[j],]$enrichment_score
    sig_branches$Ligand_foldChange[j] <- LR_pairs_subset[LR_pairs_subset$Conc == sig_branches$Conc[j],]$Ligand_foldChange
    sig_branches$Receptor_foldChange[j] <- LR_pairs_subset[LR_pairs_subset$Conc == sig_branches$Conc[j],]$Receptor_foldChange
  }
  
  # Remove 'signaling_pathway' from the Pathway_name column
  sig_branches$Pathway_name <- gsub('_signaling_pathway', '', sig_branches$Pathway_name)
  # Trim any extra whitespace that might remain after removal
  sig_branches$Pathway_name <- trimws(sig_branches$Pathway_name)
  
  sig_branches$enrichment_category <- cut(sig_branches$enrichment_score, 
                                          breaks = c(-Inf, 0.5, 1, 1.5, 2, 2.5, Inf),
                                          labels = c("0 - 0.5", "0.5 - 1", "1 - 1.5", "1.5 - 2", "2 - 2.5", "> 2.5"))
  # Reverse the order of the levels
  sig_branches$enrichment_category <- factor(sig_branches$enrichment_category, 
                                             levels = c("> 2.5", "2 - 2.5", "1.5 - 2", "1 - 1.5", "0.5 - 1", "0 - 0.5"))
  
  ggplot(data = sig_branches,
         aes(axis1 = From, axis2 = To, axis3 = Pathway_name)) +
    scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), position = 'bottom') +
    # scale_x_discrete(limits = c("Ligand", "Receptor", "Pathway"), expand = c(.2, -.05)) +
    geom_alluvium(aes(fill = enrichment_category)) +
    geom_stratum() +
    geom_text(stat = "stratum", aes(label = after_stat(stratum)), fontface = "bold", size = 3) +
    theme_void() +
    ggtitle(paste0(sender_name, ' - ', receiver_name, " Crosstalk")) +
    labs(fill='Enrichment Score') +
    theme(plot.title = element_text(size=20),
          legend.title = element_text(size=20),
          legend.text = element_text(size=15),
          axis.text.y = element_blank(),
          axis.text=element_text(size=25,face="bold"),
          plot.margin = margin(t = 0, r = 5, b = 0, l = 5),
          axis.text.x = element_text(margin = margin(t = -15)))+
    scale_fill_manual(values = c("> 2.5" = '#9932cc',
                                 "2 - 2.5" = '#ba55d3', 
                                 "1.5 - 2" = '#7b68ee', 
                                 "1 - 1.5" = '#6495ed', 
                                 "0.5 - 1" = '#87ceeb', 
                                 "0 - 0.5" = '#add8e6'))
  ggsave(paste0('/Users/vladimirwan/Desktop/Methodist/Project/S2C2-source-code/jianting_paper/alluvial-test/',sender_name,'_',receiver_name,'.pdf'), width = 15, height = 10)
}



### Code for heatmap figure generation
library(pheatmap)
library(dplyr)
library(tidyr)
before_tx <- c("1717892176710","1717892176745","1717892176768") # EM, RM, CM to EM
after_tx <- c("sender_EM_receiver_EM_NA","sender_RM_receiver_EM_NA","sender_CM_receiver_EM_NA")

save_dir <- '/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_S2C2_Jun_8 1'
# filenames <- list.files(save_dir)
data_dir = paste0(save_dir,"/",before_tx)

save_dir <- '/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_after_treatment/S2C2'
data_dir2 = paste0(save_dir,"/",after_tx)


for (i in 1:length(data_dir)){
  sender_receiver <- list.files(data_dir[i], pattern = 'sender_')
  sender_name <- strsplit(strsplit(sender_receiver, 'sender_')[[1]][2],'_receiver_')[[1]][1]
  receiver_name <- strsplit(strsplit(sender_receiver, '_receiver_')[[1]][2],'_NA')[[1]][1]
  results_dir = paste0(data_dir[i],'/',sender_receiver)
  
  before_tx_LR_pairs <- read.csv(paste0(results_dir,'/LR_pairs.txt'),sep='\t')
  before_tx_sig_branches <- read.csv(paste0(results_dir,'/significant_branches.txt'),sep='\t')
  before_tx_sig_branches$Conc2 <- paste0(before_tx_sig_branches$From, "_", before_tx_sig_branches$To)
  
  before_tx_sig_branches <- before_tx_sig_branches[before_tx_sig_branches$Signaling_protein == "Ligand",]
  LR_names <- unique(before_tx_sig_branches$Conc2)
  before_tx_LR_pairs$Conc <- paste0(before_tx_LR_pairs$Ligand, "_", before_tx_LR_pairs$Receptor)
  before_tx_LR_pairs_subset <- before_tx_LR_pairs[is.element(before_tx_LR_pairs$Conc, LR_names),]
  
  for (j in 1:nrow(before_tx_sig_branches)){
    before_tx_sig_branches$enrichment_score[j] <- before_tx_LR_pairs_subset[before_tx_LR_pairs_subset$Conc == before_tx_sig_branches$Conc2[j],]$enrichment_score
    before_tx_sig_branches$Ligand_foldChange[j] <- before_tx_LR_pairs_subset[before_tx_LR_pairs_subset$Conc == before_tx_sig_branches$Conc2[j],]$Ligand_foldChange
    before_tx_sig_branches$Receptor_foldChange[j] <- before_tx_LR_pairs_subset[before_tx_LR_pairs_subset$Conc == before_tx_sig_branches$Conc2[j],]$Receptor_foldChange
  }
  # Remove 'signaling_pathway' from the Pathway_name column
  before_tx_sig_branches$Pathway_name <- gsub('_signaling_pathway', '', before_tx_sig_branches$Pathway_name)
  # Trim any extra whitespace that might remain after removal
  before_tx_sig_branches$Pathway_name <- trimws(before_tx_sig_branches$Pathway_name)
  
  before_tx_sig_branches$enrichment_category <- cut(before_tx_sig_branches$enrichment_score, 
                                          breaks = c(-Inf, 0.5, 1, 1.5, 2, 2.5, Inf),
                                          labels = c("0 - 0.5", "0.5 - 1", "1 - 1.5", "1.5 - 2", "2 - 2.5", "> 2.5"))
  # Reverse the order of the levels
  before_tx_sig_branches$enrichment_category <- factor(before_tx_sig_branches$enrichment_category, 
                                             levels = c("> 2.5", "2 - 2.5", "1.5 - 2", "1 - 1.5", "0.5 - 1", "0 - 0.5"))
  
  after_tx_LR_pairs <- read.csv(paste0(data_dir2[i],'/LR_pairs.txt'),sep='\t')
  after_tx_sig_branches <- read.csv(paste0(data_dir2[i],'/significant_branches.txt'),sep='\t')
  after_tx_sig_branches$Conc2 <- paste0(after_tx_sig_branches$From, "_", after_tx_sig_branches$To)
  
  after_tx_sig_branches <- after_tx_sig_branches[after_tx_sig_branches$Signaling_protein == "Ligand",]
  LR_names <- unique(after_tx_sig_branches$Conc2)
  after_tx_LR_pairs$Conc <- paste0(after_tx_LR_pairs$Ligand,  "_", after_tx_LR_pairs$Receptor)
  after_tx_LR_pairs_subset <- after_tx_LR_pairs[is.element(after_tx_LR_pairs$Conc, LR_names),]
  
  for (j in 1:nrow(after_tx_sig_branches)){
    after_tx_sig_branches$enrichment_score[j] <- after_tx_LR_pairs_subset[after_tx_LR_pairs_subset$Conc == after_tx_sig_branches$Conc2[j],]$enrichment_score
    after_tx_sig_branches$Ligand_foldChange[j] <- after_tx_LR_pairs_subset[after_tx_LR_pairs_subset$Conc == after_tx_sig_branches$Conc2[j],]$Ligand_foldChange
    after_tx_sig_branches$Receptor_foldChange[j] <- after_tx_LR_pairs_subset[after_tx_LR_pairs_subset$Conc == after_tx_sig_branches$Conc2[j],]$Receptor_foldChange
  }
  
  # Remove 'signaling_pathway' from the Pathway_name column
  after_tx_sig_branches$Pathway_name <- gsub('_signaling_pathway', '', after_tx_sig_branches$Pathway_name)
  # Trim any extra whitespace that might remain after removal
  after_tx_sig_branches$Pathway_name <- trimws(after_tx_sig_branches$Pathway_name)
  after_tx_sig_branches$enrichment_category <- cut(after_tx_sig_branches$enrichment_score, 
                                          breaks = c(-Inf, 0.5, 1, 1.5, 2, 2.5, Inf),
                                          labels = c("0 - 0.5", "0.5 - 1", "1 - 1.5", "1.5 - 2", "2 - 2.5", "> 2.5"))
  # Reverse the order of the levels
  after_tx_sig_branches$enrichment_category <- factor(after_tx_sig_branches$enrichment_category, 
                                             levels = c("> 2.5", "2 - 2.5", "1.5 - 2", "1 - 1.5", "0.5 - 1", "0 - 0.5"))
  # Find common pathways
  common_pathways <- intersect(before_tx_sig_branches$Pathway_name, after_tx_sig_branches$Pathway_name)
  
  # Filter data for common pathways
  before_common <- before_tx_sig_branches %>% filter(Pathway_name %in% common_pathways)
  after_common <- after_tx_sig_branches %>% filter(Pathway_name %in% common_pathways)
  
  # Combine the datasets
  combined_data <- bind_rows(before_common %>% mutate(Treatment = "Before"),
                             after_common %>% mutate(Treatment = "After"))
  # Summarize data to get mean enrichment scores for each combination
  combined_data_summary <- combined_data %>%
    unite("Ligand_Receptor", From, To, sep = "_") %>%
    group_by(Ligand_Receptor, Pathway_name, Treatment) %>%
    summarize(mean_enrichment_score = mean(enrichment_score, na.rm = TRUE), .groups = 'drop')

  # Prepare data for heatmap
  heatmap_data <- combined_data_summary %>%
    pivot_wider(names_from = Treatment, values_from = mean_enrichment_score) %>%
    mutate(Before = as.numeric(replace_na(Before, 0)),
           After = as.numeric(replace_na(After, 0)))
  
  # Categorize the enrichment scores into bins
  heatmap_data <- heatmap_data %>%
    mutate(Before_treatment = cut(Before, breaks = c(-Inf, 0.5, 1, 1.5, 2, 2.5, Inf),
                                 labels = c("0-0.5", "0.5-1", "1-1.5", "1.5-2", "2-2.5", ">2.5")),
           After_treatment = cut(After, breaks = c(-Inf, 0.5, 1, 1.5, 2, 2.5, Inf),
                                labels = c("0-0.5", "0.5-1", "1-1.5", "1.5-2", "2-2.5", ">2.5")))
  
  # Melt the data for ggplot
  heatmap_data_melt <- heatmap_data %>%
    pivot_longer(cols = c(Before_treatment, After_treatment), names_to = "Treatment", values_to = "Enrichment_Score_Category")
  
  # Set the order of the Treatment factor
  heatmap_data_melt$Treatment <- factor(heatmap_data_melt$Treatment, levels = c("Before_treatment", "After_treatment"))
  
  # Set the order of the Enrichment_Score_Category factor
  heatmap_data_melt$Enrichment_Score_Category <- factor(heatmap_data_melt$Enrichment_Score_Category, 
                                                        levels = c(">2.5", "2-2.5", "1.5-2", "1-1.5", "0.5-1", "0-0.5"))
  # Plot the heatmap
  ggplot(heatmap_data_melt, aes(x = Ligand_Receptor, y = Pathway_name, fill = Enrichment_Score_Category)) +
    geom_tile(color = "white") +
    facet_wrap(~ Treatment, scales = "free_x") +
    scale_fill_manual(values = c("0-0.5" = "#add8e6", 
                                 "0.5-1" = "#87ceeb", 
                                 "1-1.5" = "#6495ed", 
                                 "1.5-2" = "#7b68ee", 
                                 "2-2.5" = "#ba55d3", 
                                 ">2.5" = "#9932cc"),
                      name = "Enrichment Score") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          axis.text = element_text(size = 12),
          axis.title = element_text(size = 14),
          strip.text = element_text(size = 14, face = "bold"),
          panel.border = element_rect(color = "black", fill = NA),
          panel.background = element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank()) +
    labs(title = "Heatmap of Ligand-Receptor Pairs",
         x = "Ligand-Receptor Pair", y = "Pathway Name")
  ggsave(paste0('/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_Grant/Heatmap/before_vs_after_',sender_name,'_',receiver_name,'_v2.pdf'), width = 20, height = 15)
  
  # Plot the heatmap with dots
  ggplot(heatmap_data_melt, aes(x = Ligand_Receptor, y = Pathway_name, color = Enrichment_Score_Category)) +
    geom_point(size = 5, shape = 16) +
    facet_wrap(~ Treatment, scales = "free_x") +
    scale_color_manual(values = c("0-0.5" = "#add8e6", 
                                  "0.5-1" = "#87ceeb", 
                                  "1-1.5" = "#6495ed", 
                                  "1.5-2" = "#7b68ee", 
                                  "2-2.5" = "#ba55d3", 
                                  ">2.5" = "#9932cc"), 
                       name = "Enrichment Score") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          axis.text = element_text(size = 12),
          axis.title = element_text(size = 14),
          strip.text = element_text(size = 14, face = "bold"),
          panel.border = element_rect(color = "black", fill = NA),
          panel.background = element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank()) +
    labs(title = "Heatmap of Ligand-Receptor Pairs for Common Pathways",
         x = "Ligand-Receptor Pair", y = "Pathway Name")
  
  ggsave(paste0('/Users/juyoung/Library/CloudStorage/OneDrive-HoustonMethodist/AD_scRNAseq_Crosstalk/Kun_Grant/Heatmap/dotplot_before_vs_after_',sender_name,'_',receiver_name,'.pdf'), width = 20, height = 15)
}




