library(Seurat)
library(SingleCellExperiment)
library(openxlsx)
library(presto)
library(jsonlite)
library(DescTools)
library(plyr)
library(dplyr)
library(homologene)
library(ggplot2)
library(ggalluvial)
library(circlize)
library(reshape2)

save_dir <- getwd()

source(paste0(save_dir,"/1_start_LR_identified.R"))
source(paste0(save_dir,"/2_identify_select_pathways_backup.R"))
source(paste0(save_dir,"/3_activated_pathways.R"))
source(paste0(save_dir,"/4_permutation_for_significance.R"))
source(paste0(save_dir,"/5_visualization.R"))

read_file <- function(file_path) {
  # Open the file in binary read mode
  file_conn <- file(file_path, "rb")
  
  # Read the binary data
  binary_data <- readBin(
    con = file_conn,
    what = "integer",
    n = 10
  )
  
  # Close the file connection
  close(file_conn)
  
  # Return the binary data
  return(binary_data)
}

LR_database = read_file(paste0(save_dir, '/data/LR_manual_revised.txt.encryted'))
TF_targets = read_file(paste0(save_dir, '/data/TF_targets.txt.encryted'))
ipa = read_file(paste0(save_dir, '/data/IPA_database.txt.encryted'))
kegg = read_file(paste0(save_dir, '/data/KEGG_all_edge_new.txt.encryted'))



print ("==================data loading completed=============")

nodeCount = 0
pathwayCount = 0
#  MAIN FUNCTION

sCCCExplorer <- function(seurat_object, 
                         specified_sender, 
                         specified_receiver, 
                         exp_matrix_slot, 
                         global_or_local, 
                         export_directory_path, 
                         condition_colname, 
                         condition1, 
                         LR_database, 
                         TF_targets, 
                         pathway_database_list, 
                         condition2=NA, 
                         percent_exp = 0.1, 
                         logfc_threshold = 0.25, 
                         disease = "AD", 
                         intermediate_downstream_gene_num = 2, 
                         permutation_num = 500,
                         lambda = 1.0,
                         species = 'mice',
                         assay = "RNA"
                         ){
  
  print("Welcome to sCCCExplorer: single-Cell Cross Communication Explorer!")
  if(dir.exists(export_directory_path) == FALSE){
    dir.create(export_directory_path)
  }

#   export_directory_path <- paste0(export_directory_path, "sCCCExplorer/")
  
   subfolder_name <- if(is.na(condition2) == FALSE) {
    paste0("sender_", specified_sender, "_receiver_", specified_receiver)
  } else {
    paste0("sender_", specified_sender, "_receiver_", specified_receiver, "_", condition2)
  }
  

   export_directory_path <- file.path(export_directory_path, subfolder_name)

  if (!dir.exists(export_directory_path)) {
      dir.create(export_directory_path, recursive = TRUE)
  }
   
  #1: prepare external pathway databases
  # source("./prepare_databases.R")
  collective_database <- prepare_database(pathway_database_list, disease = "AD")
  print("================== Database Preview (following collective_database is ) ==================")
  print(head(collective_database))
  print("==================== 1 ✅ ====================")

  
  #2: find differentially expressed genes for sender and overall expression for receiver
  print("Determining Overall Expression of Receiver and Differentially Expressed Genes for Sender")
  print(paste0("Specified Sender: ", specified_sender))
  print(paste0("Specified Receiver: ", specified_receiver))
  results <- find_sender_receiver_genes(seurat_object = seurat_object, specified_sender = specified_sender, specified_receiver = specified_receiver, condition_colname = condition_colname, condition1 = condition1, condition2 = condition2,
                                        percent_exp = percent_exp, logfc_threshold = logfc_threshold, assay)
  pre_dataframes <- results[[1]]
  markers_df <- results[[2]]
  print("==================== 2 ✅ ====================")
 
 if (species != 'human'){
    ### Modify the list to human gene names.
    df1_s <- paste0("Sender_Markers_", specified_sender)
    df2_r <- paste0("Receiver_Overall_", specified_receiver)
    
    lookup <- homologene::mouse2human(rownames(pre_dataframes[df1_s][[1]]), db = homologene::homologeneData2)
    new_rownames <- lookup$humanGene[match(rownames(pre_dataframes[df1_s][[1]]), lookup$mouseGene)]
    for (i in 1:length(new_rownames)){
      if (isTRUE(is.na(new_rownames[i]))){
        new_rownames[i] <- toupper(rownames(pre_dataframes[df1_s][[1]])[i])
      }
    }
    
    pre_dataframes[df1_s][[1]]$gene <- new_rownames
    pre_dataframes[df1_s][[1]] <- pre_dataframes[df1_s][[1]] %>% distinct(gene, .keep_all = TRUE)
    rownames(pre_dataframes[df1_s][[1]]) <- pre_dataframes[df1_s][[1]]$gene 
    
    # pre_dataframes[df2_r]
    lookup <- homologene::mouse2human(rownames(pre_dataframes[df2_r][[1]]), db = homologene::homologeneData2)
    new_rownames <- lookup$humanGene[match(rownames(pre_dataframes[df2_r][[1]]), lookup$mouseGene)]
    for (i in 1:length(new_rownames)){
      if (isTRUE(is.na(new_rownames[i]))){
        new_rownames[i] <- toupper(rownames(pre_dataframes[df2_r][[1]])[i])
      }
    }
    pre_dataframes[df2_r][[1]]$gene <- new_rownames
    pre_dataframes[df2_r][[1]] <- pre_dataframes[df2_r][[1]] %>% distinct(gene, .keep_all = TRUE)
    rownames(pre_dataframes[df2_r][[1]]) <- pre_dataframes[df2_r][[1]]$gene 
    
    # Markers_df
    for (mdf in 1:length(markers_df)){
      lookup <- homologene::mouse2human(rownames(markers_df[[mdf]]), db = homologene::homologeneData2)
      new_rownames <- lookup$humanGene[match(rownames(markers_df[[mdf]]), lookup$mouseGene)]
      for (i in 1:length(new_rownames)){
        if (isTRUE(is.na(new_rownames[i]))){
          new_rownames[i] <- toupper(rownames(markers_df[[mdf]])[i])
        }
      }
      markers_df[[mdf]]$gene <- new_rownames
      markers_df[[mdf]]<- markers_df[[mdf]][!duplicated(markers_df[[mdf]]$gene),]
      rownames(markers_df[[mdf]]) <- markers_df[[mdf]]$gene
    }
  }
  

  #3: prepare dataframes
  user_dataframes <- prepare_sender_receiver(pre_dataframes[[1]], pre_dataframes[[2]], collective_database, logfc_threshold = logfc_threshold, condition1 = condition1, condition2 = condition2)

  print("Exporting Sender Differentially Expressed Markers and Receiver Overall Expression Values")
  write.table(user_dataframes$sender_dataframe, paste0(export_directory_path, "/sender_markers_", specified_sender, ".txt"), quote = FALSE, sep = '\t', row.names = FALSE)
  write.table(user_dataframes$receiver_dataframe, paste0(export_directory_path, "/receiver_overall_", specified_receiver, ".txt"), quote = FALSE, sep = '\t', row.names = FALSE)
  print("==================== 3 ✅ ====================")

    
  #4: find expressed ligand receptors
  print("Finding Expressed Ligand Receptor Interactions (LR pairs)")
  ligand_receptor_dataframe <- find_ligand_receptor_pairs(seurat_object = seurat_object, markers_df = markers_df, specified_sender = specified_sender, specified_receiver = specified_receiver, sender_df = user_dataframes$sender_dataframe, receiver_df = user_dataframes$receiver_dataframe, 
                                                          LR_database = LR_database, condition_colname = condition_colname, condition1 = condition1, condition2 = condition2)
  
  
  if(length(ligand_receptor_dataframe) == 1){
    result <- "No Identified Ligand Receptor Pairs found in Crosstalk"
    print(result)
    write(result, paste0(export_directory_path, "/no_ligand_receptors.txt"))
  } else {
    print("Exporting Expressed Ligand Receptor Dataframe to export directory path")
    write.table(ligand_receptor_dataframe, paste0(export_directory_path, "/LR_pairs.txt"), quote = FALSE, row.names = FALSE, sep = '\t')
    print("==================== 4 ✅ ====================")


     #5: find activated pathways
    print("Finding Possible Pathways from Identified LR pairs")
    prelim_LRs <- find_preliminary_pathways(ligand_receptor_dataframe, collective_database)
    print("Finding Possible Activated Pathways")
    activated_pathways_overview <- find_activated_branches(prelim_LRs, user_dataframes$receiver_dataframe, intermediate_downstream_gene_num = intermediate_downstream_gene_num, TF_targets = TF_targets)
    if(length(activated_pathways_overview) == 1){
      result <- "sCCCExplorer cannot continue crosstalk pathway analysis. User-specific downstream targets were not found in the expression data provided."
      print(result)
      write(result, paste0(export_directory_path, "/no_pathways.txt"))
    } else {
      node_table <- create_node_exp_table(activated_pathways_overview, user_dataframes$sender_dataframe, user_dataframes$receiver_all_dataframe)
      print("Exporting Node/Vertex table of avg_log2FC values to export directory path")
      write.table(node_table, paste0(export_directory_path, "/node_table_logFC.txt"), quote = FALSE, sep = '\t', row.names = FALSE)
      print("==================== 5 ✅ ====================")
      
      #6: assign weights to each graph
      print("Assigning User Specific Values to Each Activated Pathway Identified: ")
      if (species != 'human'){
        # weighted_graphs <- construct_weighted_graph_ST(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
        #                                                receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        output <- construct_weighted_graph_ST(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
                                              receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        weighted_graphs <- output[[1]]
        new_pathway_df_list <- output[[2]]
        
      } else {
        # weighted_graphs <- construct_weighted_graph(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
        #                                             receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        output <- construct_weighted_graph(seurat_object, sender_cell = specified_sender, target_cell = specified_receiver, exp_matrix_slot = exp_matrix_slot, database_df = activated_pathways_overview, sender_df = user_dataframes$sender_dataframe, 
                                           receiver_df = user_dataframes$receiver_all_dataframe, global_or_local = global_or_local)
        weighted_graphs <- output[[1]]
        new_pathway_df_list <- output[[2]]
        
      }
      print("==================== 6 ✅ ====================")
      
      #7: determine significance of each branch based on permutation test
      print("Calculating Pathway Significance by Permutation Test")
      # weights_dataframe <- c()
      # for (i in 1:length(markers_df)){weights_dataframe<-rbind(weights_dataframe, markers_df[[i]])}
      # weights_dataframe <- FindMarkers(seurat_object, ident.1 = specified_receiver, features = rownames(seurat_object), min.pct = 0, verbose = FALSE, logfc.threshold = 0, test.use = "wilcox")
      final_dataframe <- find_sig_of_pathway_branches_v2(graph_list = weighted_graphs, export_directory_path=export_directory_path, collective_database = collective_database, overall_dataframe = new_pathway_df_list, receiver_df = user_dataframes$receiver_all_dataframe, permutation_num = permutation_num, lambda=lambda)
      print("Exporting Ranked Pathway's Significance to export directory path")
      write.table(final_dataframe, paste0(export_directory_path, "/significant_branches.txt"), sep = '\t', quote = FALSE, row.names = FALSE)
      print("==================== 7 ✅ ====================")
  
    
significant_branches_path <- paste0(export_directory_path, "/significant_branches.txt")
significant_branches <- read.delim(significant_branches_path, sep = "\t")

parent_directory_path <- dirname(export_directory_path)

sub_pathway_dir <- file.path(parent_directory_path, "sub_pathway")
dir.create(sub_pathway_dir, showWarnings = FALSE, recursive = TRUE)

# combined pathway
combined_pathway <- significant_branches %>%
  select(From, To, Type, Signaling_protein) %>%
  mutate(
    Direction = "directed",
    Type = ifelse(Signaling_protein == "Ligand", "LR", Type)
  ) %>%
  select(From, To, Direction, Type) %>%
  distinct()


pathwayCount <- nrow(combined_pathway)

combined_pathway_path <- paste0(parent_directory_path, "/combined pathway.txt")
write.table(combined_pathway, combined_pathway_path, sep = "\t", row.names = FALSE, quote = FALSE)


# combined pathway node 
pathway_nodes <- significant_branches %>%
  select(From, Signaling_protein, Pathway_name) %>%
  distinct() %>%
  group_by(From) %>%
  summarise(
    gene_type = case_when(
      Signaling_protein == "Signaling" ~ "links",
      Signaling_protein == "Leaf" ~ "TF",
      TRUE ~ as.character(Signaling_protein)
    ),
    pathway = paste(unique(Pathway_name), collapse = ";")
  ) %>%
  ungroup() %>%
  rename_(.dots = setNames("From", "gene"))


pathway_nodes_path <- paste0(parent_directory_path, "/combined pathway_nodes.txt")

pathway_nodes_unique <- pathway_nodes %>% 
  distinct(gene, .keep_all = TRUE)

write.table(pathway_nodes_unique, pathway_nodes_path, sep = "\t", row.names = FALSE, quote = FALSE)

nodeCount <- nrow(pathway_nodes)



# print("==================> 👌 combined pathway nodes write done 👌 <==========================")


# subpathway_list.txt
pathway_file_list <- significant_branches %>%
  select(Pathway_name, p_val) %>%
  distinct(Pathway_name, .keep_all = TRUE) %>%
  mutate(
    pathway_node_source = paste0(Pathway_name, "_nodes.txt"),
    pathway_source = paste0(Pathway_name, ".txt")
  ) %>%
  arrange(p_val) %>% 
  select(Pathway_name, p_val, pathway_node_source, pathway_source)

# colnames(pathway_file_list) <- NULL
pathway_file_list_path <- paste0(parent_directory_path, "/pathway_file_list.txt")
write.table(pathway_file_list, pathway_file_list_path, sep = "\t", row.names = FALSE, quote = FALSE)

# print("==================> 🔥 START Subapathway 🔥 <==========================")
pathway_file_list <- read.delim(pathway_file_list_path, sep = "\t")
combined_pathway_nodes <- read.delim(pathway_nodes_path, sep = "\t")
combined_pathway <- read.delim(combined_pathway_path, sep = "\t")



# print("==================> 🔥 1. LOOP 🔥 <==========================")
for (py in pathway_file_list$Pathway_name) {
  escaped_pathway <- str_replace_all(py, "\\(|\\)|\\[|\\]", "\\\\\\0")
  pattern <- paste0("(^|;)", escaped_pathway, "($|;)")

   pathway_nodes <- combined_pathway_nodes %>%
    filter(str_detect(pathway, regex(pattern, ignore_case = TRUE))) %>%
    distinct(gene, .keep_all = TRUE)
  
  
  # print("==================> 🔥 2. SUB-NODES 🔥 <==========================")
  write.table(pathway_nodes, 
              file.path(sub_pathway_dir, paste0(py, "_nodes.txt")),
              sep = "\t", row.names = FALSE, quote = FALSE, col.names = TRUE)

pathway_edges <- combined_pathway %>%
  filter(From %in% pathway_nodes$gene & To %in% pathway_nodes$gene)
  
  # print("==================> 🔥 3. SUB-PATHWAY 🔥 <==========================")
  write.table(pathway_edges, 
              file.path(sub_pathway_dir, paste0(py, ".txt")), 
              sep = "\t", row.names = FALSE, quote = FALSE, col.names = TRUE)
}

# print("========= 🔥All sub-pathway files have been generated.🔥 =============")

      #8: create text file for visualization 
      cytoscape_all <- prepare_text_file(weighted_graphs, final_dataframe, pval = 1)
      write.table(cytoscape_all, paste0(export_directory_path, "/cytoscape_all_file.txt"),
                  quote = FALSE, sep = '\t', row.names = FALSE)
      cytoscape_file <- prepare_text_file(weighted_graphs, final_dataframe)
      print("Exporting Pathway Table as text file to export directory path")
      write.table(cytoscape_file, paste0(export_directory_path, "/cytoscape_significant_file.txt"),
                  quote = FALSE, sep = '\t', row.names = FALSE)
      print("sCCCExplorer Complete!")
      print("================== 8 ✅  ========================")



replace_spaces <- function(text) {
  gsub(" ", "_", text)
}

      return(list(nodeCount = nodeCount, pathwayCount = pathwayCount))
    }
  }
}


load(paste0(save_dir, '/data/init.RData'))

#  ---------------------- FIXED VARIABLE ----------------------
# ⭐️Change those content!!!!⭐️
# layout, config

pathway_database_list = list(ipa, kegg)

# ---------------------- SYSTEM FETCH SYSTEM ARGUMENTS ----------------------

# ---------------------- OUTPUT MIDDLEWARE DATA ----------------------

args <- commandArgs(trailingOnly = TRUE)

# ==========⭐️ REQUIRED args ⭐️==========
log_file_path <- args[1]
print(paste("The report file is ===> ", log_file_path))

if (length(args) < 2) {
    stop("❌RDS file path not provided in command line arguments.")
}
# GET RDS FILE DATA 
path_rds_file <- args[2]
print(paste("Path_rds_file is ===> ", path_rds_file))
seurat_object = readRDS(path_rds_file)
metadata <- seurat_object@meta.data



user_celltype_colname <- args[3]
if (!(user_celltype_colname %in% colnames(metadata))) {
    stop(paste("❌ The provided cell type column name", user_celltype_colname, "is not a valid column in the RDS file metadata."))
}

Idents(seurat_object) <- user_celltype_colname

unique_celltype = unique(Idents(seurat_object))
unique_column_name = colnames(metadata)
jsonlite::write_json(unique_celltype,  path = paste0(save_dir, "/celltype.json"))
jsonlite::write_json(metadata, path = paste0(save_dir, "/metadata.json"))
celltypes_str = paste(unique_celltype, collapse = ",")
writeLines(celltypes_str, con = paste0(save_dir, "/all_celltype.txt"))

condition_colname <- args[4]
if (!(condition_colname %in% unique_column_name)) {
    stop(paste("❌ The provided condition column name", condition_colname, "is not a valid column in the metadata."))
}
print(paste("Condition_colname is ===> ", condition_colname))
unique_values <- unique(seurat_object@meta.data[[condition_colname]])

condition1 <- args[5]

if (!(condition1 %in% unique_values)) {
    stop(paste("❌ The provided condition value", condition1, "is not valid for the column", condition_colname, ". Valid values are:", paste(unique_values, collapse=", ")))
}

print(paste("Phenotype1 is ===> ", condition1))

if (length(args) < 6) {
  stop("❌ Not enough arguments provided. Please provide path_rds_file, condition_colname, and condition1 as required arguments.")
}
# print("============ 📖 REQUIRED PART IS DONE! 📖 ================")
# ==========💡 OPTIONAL args 💡==========
if (length(args) >= 6 && nzchar(args[6])) {
  condition2 <- args[6]
    if (condition2 == "NA") {
        condition2 <- NA
    }

    if (!(condition2 %in% unique_values) && !is.na(condition2)) {
        stop("❌ The provided condition2 value ", condition2, " is not valid for the column ", condition_colname, ". Valid values are: ", paste(unique_values, collapse=", "))
    }

   if (!is.na(condition2) && condition2 == condition1) {
        stop("❌ condition2 cannot be the same as condition1. Both are: ", condition1)
    }
} else {
    condition2 <- NA
}

print(paste("Phenotype2 is ===>", condition2))

if (length(args) >= 7) {
    sendlist_path <- args[7]
} else {
    sendlist_path <- "/all_celltype.txt"
}

sender_list <- strsplit(readLines(sendlist_path), split=",")[[1]]
sender_list <- gsub("\"", "", sender_list)
sender_list <- trimws(sender_list)
print("===== ⬇ Sender list contains those cell types ⬇ =====")
print(sender_list)
print("===== ⬆ Sender list contains those cell types ⬆ =====")


if (length(args) >= 8) {
    receiverlist_path <- args[8]

} else {
    receiverlist_path <- "/all_celltype.txt"
}

receiver_list <- strsplit(readLines(receiverlist_path), split=",")[[1]]
receiver_list <- gsub("\"", "", receiver_list)
receiver_list <- trimws(receiver_list)
print("===== ⬇ Receiver list contains those cell types ⬇ =====")
print(receiver_list)
print("===== ⬆ Receiver list contains those cell types ⬆ =====")

global_method <- "global"

print(paste("global_method is ===> ", global_method))


# （0 - 1)
percent_exp <- if(length(args) >= 9 && !is.na(as.numeric(args[9]))) {
    temp_percent_exp <- as.numeric(args[9])
    if(temp_percent_exp >= 0 && temp_percent_exp <= 1) {
        temp_percent_exp
    } else {
        stop("❌ Error: percent_exp must be a numeric value between 0 and 1.")
    }
} else {
    0.005
}

print(paste("percent_exp is ===> ", percent_exp))

logfc_threshold <- if(length(args) >= 10 && !is.na(as.numeric(args[10]))) {
    temp_logfc_threshold <- as.numeric(args[10])
    if(temp_logfc_threshold > 0) {
        temp_logfc_threshold
    } else {
        stop("❌ Error: logfc_threshold must be a numeric value greater than 0.")
    }
} else {
    0.20
}
print(paste("logfc_threshold ===> ", logfc_threshold))



intermediate_downstream_gene_num <- if(length(args) >= 11 && !is.na(as.numeric(args[11]))) {
    temp_intermediate_downstream_gene_num <- as.numeric(args[11])
    if(temp_intermediate_downstream_gene_num > 0) {
        as.integer(temp_intermediate_downstream_gene_num)
    } else {
        stop("❌ Error: intermediate_downstream_gene_num must be a numeric value greater than 0.")
    }
} else {
    2
}
print(paste("intermediate_downstream_gene_num is ===> ", intermediate_downstream_gene_num))


permutation_num <- if(length(args) >= 12 && !is.na(as.numeric(args[12]))) {
    temp_permutation_num <- as.numeric(args[12])
    if(temp_permutation_num > 0) {
        as.integer(temp_permutation_num)
    } else {
        stop("❌ Error: permutation_num must be a numeric value greater than 0.")
    }
} else {
    1000
}
print(paste("permutation_num is ===> ", permutation_num))



# ---------------------- USER INPUT VARIABLE ----------------------
lambda <- if(length(args) >= 13 && !is.na(as.numeric(args[13]))) {
    temp_lambda <- as.numeric(args[13])
    if(temp_lambda  >= 0 && temp_lambda  <= 1) {
        temp_lambda
    } else {
        stop("❌ Error: lambda  must be a numeric value between 0 and 1.")
    }
} else {
    0.0
}

print(paste("lambda is ===> ", lambda))

species <- if(length(args) >= 14 && nzchar(args[14])) {
    if (args[14] == "mouse" || args[14] == "human") {
        args[14]
    } else {
        stop("❌ The provided species value ", args[14], " is not valid. Valid values are: mouse or human")
    }
} else {
    "mouse"
}

print(paste("species is ===> ", species))

assay <- if(length(args) >= 15 && nzchar(args[15])) {
    if (args[15] == "RNA" || args[15] == "integrated") {
        args[15]
    } else {
        stop("❌ The provided assay value ", args[15], " is not valid. Valid values are: RNA or integrated")
    }
} else {
    "RNA" 
}

print(paste("assay is ===> ", assay))

export_dir_name <- if(length(args) >= 16 && nzchar(args[16])) {
    args[16]
} else {
    "/export"
}
print(paste("export_dir_name is ===> ", export_dir_name))

sender_receiver_list <- expand.grid(sender_list, receiver_list)

for (z in 1:nrow(sender_receiver_list)){
  results <- sCCCExplorer(seurat_object = seurat_object,
                specified_sender = sender_receiver_list[z,1],
               specified_receiver = sender_receiver_list[z,2],
               exp_matrix_slot = "scale.data",
               global_or_local = global_method,
               condition_colname = condition_colname,
               condition1= condition1, 
               LR_database = LR_database,
               TF_targets = TF_targets,
               pathway_database_list=pathway_database_list,
               condition2= condition2,
               percent_exp = percent_exp, 
               logfc_threshold = logfc_threshold,
               intermediate_downstream_gene_num = intermediate_downstream_gene_num, 
               permutation_num = permutation_num ,
               export_directory_path = export_dir_name,
              lambda = lambda,
              species = species,
              disease = "AD",
              assay = assay
  )

  nodeCount <- results$nodeCount
  pathwayCount <- results$pathwayCount
}


 gc()

errMsg = "Found the pathways successfully."
errCode = 100

reportfile = log_file_path

write.table(paste('{"errMsg":"',errMsg,'","errCode":"',errCode,'","nodeCount":"',nodeCount,'","pathwayCount":"',pathwayCount,'"}',sep=""),reportfile,row.names=F,col.names=F,quote=F,sep="\t")


print("============ 🌟 ALL DONE! 🌟 ================")